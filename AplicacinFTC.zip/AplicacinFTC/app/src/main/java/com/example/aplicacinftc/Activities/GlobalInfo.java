package com.example.aplicacinftc.Activities;

import androidx.fragment.app.Fragment;

import com.example.aplicacinftc.Models.User;


public class GlobalInfo {
    public static User UsuarioIniciado;
}
